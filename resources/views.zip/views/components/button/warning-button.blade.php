<button {{ $attributes->merge(['class' => 'btn btn-warning']) }}>
    {{ $slot }}
</button>
