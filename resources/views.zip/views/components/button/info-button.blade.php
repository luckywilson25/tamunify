<button {{ $attributes->merge(['class' => 'btn btn-info']) }}>
    {{ $slot }}
</button>
