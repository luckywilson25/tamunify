<div class="toast toast-start toast-middle">
    <div class="alert alert-success">
        <span>{{ $message }}</span>
    </div>
</div>
