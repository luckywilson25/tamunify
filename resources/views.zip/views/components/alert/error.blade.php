<div role="alert" class="alert alert-error">
    @foreach ($errors as $error)
        <span>{{ $error }}</span>
    @endforeach
</div>
